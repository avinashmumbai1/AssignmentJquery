﻿$(document).ready(function ()
{
    $("#ClickString").click(function ()
    {
        $.ajax({
            url: 'http://localhost:56785/api/values',
            type: 'GET',
            dataType: 'json',
            success: function (data, textStatus, xhr)
            {
                document.write(data);
                console.log(data);
            },
            error: function (xhr, textStatus, errorThrown)
            {
                console.log('Error in Operation');
            }
        });
    });

    $("#ClickInt").click(function ()
    {
        jQuery.support.cors = true;
        var c = $("#numb").val();
        var arg = "a=" + c;
        $.ajax({
            url: 'http://localhost:56785/api/Default/Get/?' + arg,
            type: 'GET',
            dataType: 'json',
            success: function (data, textStatus, xhr)
            {
                document.write(data);
                console.log(data);
            },
            error: function (xhr, textStatus, errorThrown)
            {
                console.log('Error in Operation');
            }
        });
    });

    $("#ShowCusomer").click(function ()
    {
        jQuery.support.cors = true;
        $.ajax({
            url: 'http://localhost:56785/api/Demo1/Get/',
            type: 'GET',
            dataType: 'json',
            success: function (data, textStatus, xhr)
            {
                debugger;
               // console.log(data);
                var mJSON = JSON.stringify(data);
                var myJSON = JSON.parse(mJSON);
                var custArray = Object.keys(data);
                var randomNumber = Math.random();
                var custIndex = Math.floor(randomNumber * custArray.length);

                var randomKey = custArray[custIndex];
                var randomValue = myJSON[randomKey];
               // console.log(randomKey);
                console.log(randomValue);
               // var randomIds = Object.keys(myJSON)[Math.floor(Math.random() * myJSON.length)];
                document.write("<br/> Generated Random ID is  : " + randomValue.Id);
               
            },
            error: function (xhr, textStatus, errorThrown)
            {
                console.log('Error in Operation');
            }
        });

    });

    $("#PromiseObject").click(function ()
    {
        function func1()
        {
            var dfd = $.Deferred();
            $.ajax({
                url: 'http://localhost:56785/api/Demo1/Get/',
                type: 'GET',
                dataType: 'json',
                success: function (data, textStatus, xhr)
                {
                    debugger;
                  //  console.log(data);
                    var mJSON = JSON.stringify(data);
                    var myJSON = JSON.parse(mJSON);
                    var custArray = Object.keys(myJSON);
                    var randomNumber = Math.random();
                    var custIndex = Math.floor(randomNumber * custArray.length);

                    var randomKey = custArray[custIndex];
                    var randomValue = myJSON[randomKey];
                   // console.log(randomKey);
                   // console.log(randomValue);
                    //var mJSON = JSON.stringify(data);
                    //var myJSON = JSON.parse(mJSON);
                    //var randomIds = Object.keys(myJSON)[Math.floor(Math.random() * myJSON.length)];
                    document.write("<br/> Generated Random ID is : " + randomValue.Id + "<br/>" + " Check console for the Customer Object data for the generated Random Customer ID ");
                    dfd.resolve(randomValue.Id);
                    console.log(randomValue.Id);
                    return dfd.promise();
                },
                error: function (xhr, textStatus, errorThrown)
                {
                    console.log('Error in Operation');
                }
            });
           
            return dfd.promise();
        }

        function func2(message)
        {
            var dfd = $.Deferred();
            $.ajax({
                url: 'http://localhost:56785/api/Demo1/GetId/' + message,
                type: 'GET',
                dataType: 'json',
                success: function (data, textStatus, xhr)
                {
                    var mJSON = JSON.stringify(data);
                    var myJSON = JSON.parse(mJSON);
                   // console.log(myJSON);
                   // var randomIds = Object.keys(myJSON)[Math.floor(Math.random() * myJSON.length)];
                  //  document.write(randomIds);
                    dfd.resolve(myJSON);
                    
                    return dfd.promise();
                },
                error: function (xhr, textStatus, errorThrown)
                {
                    console.log('Error in Operation');
                }
            });
            return dfd.promise();
        }

        // ~~~~~~~~~~ using $.when here ~~~~~~~~~~~~

        $.when(func1()).then(function (result1)
        {
            $.when(func2(result1)).then(function (result2)
            {
                console.log(result2);
            })
        });

    });
});