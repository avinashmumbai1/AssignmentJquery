﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssignmentJquery2.Controllers
{
    public class DefaultController : ApiController
    {
      //  [HttpGet]
        public int Get( int a )
        {
            Double b = Math.Sqrt((Double)a);
            int c = (Int32)b;
            return c;
        }
    }
}
