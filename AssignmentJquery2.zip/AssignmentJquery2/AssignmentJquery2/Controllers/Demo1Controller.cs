﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AssignmentJquery2.Models;

namespace AssignmentJquery2.Controllers
{
    public class Demo1Controller : ApiController
    {
        List<Customer> lst = new List<Customer>
            {
                new Customer{Id=1,CustomerName="Arun",Address="9th Street",City="Pune",Pincode="410152"},
                new Customer{Id=2,CustomerName="Mohan",Address="Main Road",City="Satara",Pincode="410155"},
                new Customer{Id=3,CustomerName="Prapbu",Address="SKV Street",City="mumbai",Pincode="410144"},
                new Customer{Id=4,CustomerName="Raja",Address="Raja Street",City="Chennai",Pincode="637207"},
                new Customer{Id=5,CustomerName="Ravi",Address="SMV Street",City="Nagpur",Pincode="410111"},
                new Customer{Id=6,CustomerName="Santhosh",Address="SKM Street",City="Solapur",Pincode="413333"},
                new Customer{Id=7,CustomerName="Mugesh",Address="Main Road",City="Thane",Pincode="410153"},
                new Customer{Id=8,CustomerName="Mani",Address="Mani Street",City="Chembur",Pincode="443232"},
                new Customer{Id=9,CustomerName="Shankar",Address="Sankar Street",City="Thosegar",Pincode="418786"},
                new Customer{Id=10,CustomerName="Vignesh",Address="Main Road",City="Karad",Pincode="4101531"}
            };
        // GET: api/Demo1
        public IEnumerable<Customer> Get()
        {
            
            return lst;
        }

        // GET: api/Demo1/5
        public IEnumerable<Customer> GetId(string id)
        {
            var returnlst = (from l in lst
                             where l.Id==Convert.ToInt32(id)
                             select l);
            return returnlst;
        }

        // POST: api/Demo1
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Demo1/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Demo1/5
        public void Delete(int id)
        {
        }
    }
}
