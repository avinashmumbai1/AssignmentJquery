// Code goes here

// Base class
function Vehicle(type, wheeltype, noun, medium) {
  this.type = type;
  this.wheeltype = wheeltype;
  this.noun = noun;
  this.medium = medium;
}
Vehicle.prototype = {
  // doing is declared on Vehicle as ;it's common to all child classes which all
  // delegate to the same function
  doing: function() {
    return `I love ${this.noun} my ${this.color} ${this.type} on the ${this.medium}`;
  }
}

function Car(model, color) {
  // run the constructor function passing in the current
  // objects context
  Vehicle.call(this, 'car', 4, 'driving', 'Ground')
    // set properties on the Car
  this.model = model;
  this.color = color;
}
// This extends the Vehicle class
Car.prototype = new Vehicle();
// this method is unique to Car
Car.prototype.drive = function() {
  return `cruisin' down the ${this.medium} in my ${this.model}`;
}

function Bike(model, color) {
  // run the constructor function passing in the current
  // objects context
  Vehicle.call(this, 'Bike', 2, 'riding', 'Ground')
    // set properties on the Bike
  this.model = model;
  this.color = color;
}
// This extends the Vehicle class
Bike.prototype = new Vehicle();
// this method is unique to Bike
Bike.prototype.ride = function() {
    return `cruisin' down the ${this.medium} in my ${this.model}`;
  }
  // used the class syntax
class Ship extends Vehicle {
  constructor(model, color) {
      // super calls the constructor with the context already set
      super('boat', 0, 'sailing', 'Water')
      this.model = model;
      this.color = color;
    }
    // unique method for a Ship
  sail() {
    return `I'm on a ${this.type}`;
  }
}

class Aeroplane extends Vehicle {
  constructor(model, color) {
      // super calls the constructor with the context already set
      super('Plane', 0, 'Flying', 'Air')
      this.model = model;
      this.color = color;
    }
    // unique method for a Aeroplane
  Fly() {
    return `I'm on a ${this.type}`;
  }
}

// create objects from  constructors
var car = new Car('BMW', 'green');
var Bike = new Bike('Harley', 'Black');
var ship = new Ship('Riviera', '24 carot gold');
var plane = new Aeroplane('Boeing', 'White');

var obj = {
  length: 0,

  addElem: function addElem(elem) {
    // obj.length is automatically incremented 
    // every time an element is added.
    [].push.call(this, elem);
  }
};

obj.addElem(car);
obj.addElem(Bike);
obj.addElem(ship);
obj.addElem(plane);

var array = Object.values(obj); 

// removing the last element from the array 
array.splice(-1, 1);

function chkind() {

  var selectedText = ddlMediums.options[ddlMediums.selectedIndex].innerHTML;

  var textbox = document.getElementById('divResult');
  const div = document.getElementById('divResult1');
  var c = Object.values(array).filter(x => x.medium === selectedText);
  var d = Object.values(c);
  var m = Object.values(d);
  textbox.innerHTML = "";

  $(".elm").remove();


  for (var a in d) {
    textbox.innerHTML = "";
    // $( ".elm" ).remove();
    var q = d[a].type;
    console.log(q);
    textbox.innerHTML += q;

    if (d.length > 1) {
      textbox.innerHTML = "";

      $("<div class='elm'><p>" + q + "</p></div>").appendTo("body");
      var elements = $();


    }

  }
}