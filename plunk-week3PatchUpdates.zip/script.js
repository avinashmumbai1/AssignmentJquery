// Code goes here

// Base class
function Vehicle(type, wheeltype, medium) {
  this.type = type;
  this.wheeltype = wheeltype;
  //this.noun = noun;
  this.medium = medium;
}
Vehicle.prototype = {
  // doing is declared on Vehicle as ;it's common to all child classes which all
  // delegate to the same function
  doing: function() {
    console.log(`I love  my ${this.color} ${this.type} on the ${this.medium}`);
    alert('I am riding a vehicle');
    // return console.log( `I love ${this.noun} my ${this.color} ${this.type} on the ${this.medium}`;
  }
}

function Car(model, color) {
  // run the constructor function passing in the current
  // objects context
  Vehicle.call(this, 'car', 4, 'Ground')
    // set properties on the Car
  this.model = model;
  this.color = color;
}
// This extends the Vehicle class
Car.prototype = new Vehicle();
// this method is unique to Car
Car.prototype.drive = function() {
  console.log(`cruisin' down the ${this.medium} in my ${this.model}`);
  alert('I am driving car');
  // return `cruisin' down the ${this.medium} in my ${this.model}`;
}

function Bike(model, color) {
  // run the constructor function passing in the current
  // objects context
  Vehicle.call(this, 'bike', 2, 'Ground')
    // set properties on the Bike
  this.model = model;
  this.color = color;
}
// This extends the Vehicle class
Bike.prototype = new Vehicle();
// this method is unique to Bike
Bike.prototype.ride = function() {
    console.log(`cruisin' down the ${this.medium} in my ${this.model}`);
    alert('I am riding a Bike ');
    // return `cruisin' down the ${this.medium} in my ${this.model}`;
  }
  // used the class syntax
class Ship extends Vehicle {
  constructor(model, color) {
      // super calls the constructor with the context already set
      super('boat', 0, 'Water')
      this.model = model;
      this.color = color;
    }
    // unique method for a Ship
  sail() {
    console.log(`I'm on a ${this.type}`);
    alert('I am sailing in a boat');
    // return `I'm on a ${this.type}`;
  }
}

class Aeroplane extends Vehicle {
  constructor(model, color) {
      // super calls the constructor with the context already set
      super('Plane', 0, 'Air')
      this.model = model;
      this.color = color;
    }
    // unique method for a Aeroplane
  Fly() {
    console.log(`I'm on a ${this.type}`);
    alert('I am flying a plane');
    //return `I'm on a ${this.type}`;
  }
}

// create objects from  constructors
var vehicle = new Vehicle('', 0, '')
var car = new Car('BMW', 'green');
var bike = new Bike('Harley', 'Black');
var ship = new Ship('Riviera', '24 carot gold');
var plane = new Aeroplane('Boeing', 'White');

var obj = [];

obj.push(car);
obj.push(bike);
obj.push(ship);
obj.push(plane);

var array = Object.values(obj);

// removing the last element from the array 
//array.splice(-1, 1);

function chkind() {

  var VehicleClick = $.proxy(vehicle.doing, vehicle);
  var CarClick = $.proxy(car.drive, car);
  var BikeClick = $.proxy(bike.ride, bike);
  var ShipClick = $.proxy(ship.sail, ship);
  var PlaneClick = $.proxy(plane.Fly, plane);

  var selectedText = ddlMediums.options[ddlMediums.selectedIndex].innerHTML;

  var textbox = document.getElementById('divResult');
  var div = document.getElementById('divResult1');
  var c = Object.values(array).filter(x => x.medium === selectedText);
  var d = Object.values(c);
  var m = Object.values(d);
  textbox.innerHTML = "";
  div.innerHTML = "";
  $("#divPlane").empty();
  $("#divBoat").empty();
  var btnPlane = "<button id='btnPlane' class='btn'>Plane Method </button> <br/> <br/>";
  var btnBoat = "<button id='btnBoat' class='btn'>Boat Method </button> <br/> <br/>";
  var btnBike = "<button id='btnBike' class='btn'>Bike Method </button> <br/> <br/>";
  var btnCar = "<button id='btnCar' class='btn'>Car Method </button> <br/> <br/>";
  var btnVehicle = "<br/> <br/> <button id='btnVehicle' class='btn'>Vehicle Method </button> <br/> <br/>";
  $(".elm").remove();
  $(".btn").remove();
  var newdiv2 = "<div id='newdiv'></div>";
  for (var a in d) {
    textbox.innerHTML = "";
    div.innerHTML = "";
    $("#p1").empty();
    var q = d[a].type;
    console.log(q);
    textbox.innerHTML += q;
    if (q === "Plane") {
      $("#p1").empty();
      $("#p2").empty();
      div.innerHTML = "";
      $("#divResult").append(btnPlane);
      $("#btnPlane").on("click", $.proxy(PlaneClick));
      $("#btnPlane").after("<div class='elm' id='divPlane'><br/> <br/> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<button id='btnVehicle' class='btn'>Vehicle Method </button> <br/> <br/></div>");
      $("#btnVehicle").on("click", $.proxy($.proxy(vehicle.doing, d[a])));
    }
    if (q === "boat") {
      $("#p1").empty();
      $("#p2").empty();
      div.innerHTML = "";
      $("#divResult").append(btnBoat);
      $("#btnBoat").on("click", $.proxy(ShipClick));
      $("#btnBoat").after("<div class='elm'  id='divBoat'><br/><br/> <br/> &nbsp; &nbsp; &nbsp; &nbsp;<button id='btnVehicle' class='btn'>Vehicle Method </button> <br/> <br/></div>");
      $("#btnVehicle").on("click", $.proxy($.proxy(vehicle.doing, d[a])));
    }

    console.log(d.length);
    if (d.length > 1) {
      // $("p1").show();
      //$("p2").show();
      // $("body").append(newdiv2);
      $("<div class='elm'><p>" + q + "</p></div>").appendTo("body");
      // for (var i = 0; i <= d.length; i++) {
      textbox.innerHTML = "";
      //console.log('hie');
      // $("body").append(newdiv2);
      // $("p" ).append( "<strong>Hello</strong>" );
      // $("p").prepend(docu<ment.createTextNode(q + "  "));
      //$("p").append('<br/> <br/> &nbsp; &nbsp;<button id="f' + i + '">text</button> <br/> <br/>');

      // $("#f2").remove();

      /*if (q === "bike") {
        $("#f0").on("click", $.proxy(BikeClick));
        $("#f0").after("<br/> <br/> &nbsp; &nbsp;<button id='btnVehicle' class='btn'>Vehicle Method </button> <br/> <br/>");
        $("#btnVehicle").on("click", $.proxy(VehicleClick));
      }
      if (q === "car") {
        $("#f1").on("click", $.proxy(CarClick));
        $("#f1").after("<br/> <br/> &nbsp; &nbsp;<button id='btnVehicle' class='btn'>Vehicle Method </button> <br/> <br/>");
        $("#btnVehicle").on("click", $.proxy(VehicleClick));
      }
    }*/
      var elements = $();
    }
    if (q === "bike") {
      $("#divResult1").append(btnBike);
      $("#btnBike").on("click", $.proxy(BikeClick));
      $("#divResult1").after("<br/> <br/> <button id='btnVehicle' class='btn'>Vehicle Method ( Bike )</button> <br/> <br/>");
      $("#btnVehicle").on("click",  $.proxy($.proxy(vehicle.doing, d[a])));
    }
    if (q === "car") {
      $("#p2").append(btnCar);
      $("#btnCar").on("click", $.proxy(CarClick));
      $("#p2").after("<br/> <br/> <button id='btnVehicle1' class='btn'>Vehicle Method ( Car ) </button> <br/> <br/>");
      $("#btnVehicle1").on("click",  $.proxy($.proxy(vehicle.doing, d[a])));
    }


  }
}